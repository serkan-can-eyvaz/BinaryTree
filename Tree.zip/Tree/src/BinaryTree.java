public class BinaryTree {
    Node root;
    public BinaryTree()
    {
        root=null;
    }
    Node newrood(int deger)
    {
        root=new Node(deger);
        //System.out.println("Kok eklendi !"+root.data);
        return  root;
    }
    Node insert( Node root,int deger)
    {
       if (root!=null)
       {
           if (deger<root.data)
           {
               root.left=insert(root.left,deger );
           }
           else
           {
               root.right=insert(root.right,deger );
           }
       }
       else
           root=newrood(deger);
           return root;
    }
    Node delete(Node root,int deger)
    {
        Node t1,t2;
        if (root==null)
        {
            return null;
        }
        else if (root.data==deger)
        {
            if (root.left==root.right)//silinecek düğümün altında düğürm yok
            {
              root=null;
              return  null;
            }
            else if(root.left==null)
            {
                t1=root.right;
                return t1;
            }
            else if(root.right==null)
            {
                t1=root.left;
                return t1;
            }
            else
            {
                t1=t2=root.right;
                while (t1.left!=null)
                {
                    t1=t1.left;
                }
                t1.left=root.left;
                return t2;
            }
        }
        else
        {
            if (deger<root.data)
            {
                root.left=delete(root.left,deger);
            }
            else
            {
                root.right=delete(root.right,deger);
            }
        }
        return root;
    }
    void preOrder(Node root)
    {
        if (root!=null)
        {

            System.out.print(" "+root.data);
            preOrder(root.left);
            preOrder(root.right);
        }
    }
    void inOrder(Node root)
    {
        if (root!=null)
        {
            inOrder(root.left);
            System.out.print(" "+root.data);
            inOrder(root.right);

        }
    }
    void postOrder(Node root)
    {
        if (root!=null)
        {
            postOrder(root.left);
            inOrder(root.right);
            System.out.print(" "+root.data);
        }
    }
}
