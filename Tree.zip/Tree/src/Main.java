public class Main {
    public static void main(String[] args) {
        BinaryTree bt=new BinaryTree();
        bt.root=bt.insert(bt.root,10);
        bt.root=bt.insert(bt.root,8);
        bt.root=bt.insert(bt.root,15);
        bt.root=bt.insert(bt.root,5);
        bt.root=bt.insert(bt.root,12);
        bt.root=bt.insert(bt.root,20);
        bt.root=bt.insert(bt.root,9);
        System.out.println(bt.root.left.left.data);

//
//        System.out.println("Kok data :"+bt.root.data);
//        System.out.println("KOk sol:"+bt.root.left.data);
//        System.out.println("Kok sag :"+bt.root.right.data);
//        System.out.println("Kok solun solu :"+bt.root.left.left.data);
//        System.out.println("Kok sagin sagi :"+bt.root.right.right.data);
//
        System.out.println("Preorder");
        bt.preOrder(bt.root);
        System.out.println("\n Inorder: ");
        bt.inOrder(bt.root);
        System.out.println("\n Postorder: ");
        bt.postOrder(bt.root);


        System.out.println("\n kok data: "+bt.root.data);
        bt.root=bt.delete(bt.root,10);
        System.out.println("\n kok data: "+bt.root.data);

    }
}