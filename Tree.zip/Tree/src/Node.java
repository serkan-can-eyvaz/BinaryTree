public class Node {
    int data;
    Node left;
    Node right;
    public Node(int deger)
    {
        this.data=deger;
        left=null;
        right=null;
    }
}
